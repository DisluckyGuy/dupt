cd ../src
mkdir build
cmake -DCMAKE_BUILD_TYPE=Release build -S . -B build
cmake --build build
mkdir "$1/usr/bin/ghostknight"
mkdir "$1/usr/bin/ghostknight/build"
cp build/GhostKnight "$1/usr/bin/ghostknight/build/ghostknight"
cp -r .res "$1/usr/bin/ghostknight/.res"