#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>

namespace ge
{
    namespace tools {
    }
} // namespace ge

#include "collisions.hpp"
#include "styling.hpp"
#include "geometry.hpp"
#include "angles.hpp"