#include "menu.hpp"

void menu::update()
{
}

void menu::render()
{
}
