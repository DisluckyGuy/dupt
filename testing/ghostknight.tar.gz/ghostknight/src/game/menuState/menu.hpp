#include "../../cppGameEngine/ge.hpp"
#include <iostream>

class menu : public ge::State {
    void update();
    void render();
};