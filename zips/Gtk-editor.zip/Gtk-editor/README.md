A text editor made in gtk
pls don't use to actually edit text
